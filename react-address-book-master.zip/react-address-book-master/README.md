# react-address-book

### Setup

Clone the repository.

```
$ https://github.com/Improwised/react-address-book.git
```

Install all dependencies througn npm.

```
$ npm install
```

Install global dependencies througn npm.

```
$ npm install -g webpack
```
Prepare static assets manually for the first run.

```
$ webpack
```

Run the app
```
$ npm start
```
