module.exports = [
    {
      "id": 1,
      "name": {'firstname':'Glover','lastname':'Baldwin' },
      "phoneno": 8194443126,
      "address":{
        'street'  : '738 Ovington Court',
        'state'   : 'Utah',
        'city'    : 'Soudan',
        'zipcode' : 471400,
        'country' : "Cote D\"Ivoire"
      }
    },
    {
      "id": 2,
      "name": {'firstname':'Ila','lastname':'Donovan' },
      "phoneno": 9684342873,
      "address":{
        'street'  : '589 Jaffray Street',
        'state'   : 'South Carolina',
        'city'    : 'Hollins',
        'zipcode' : 800000,
        'country' : 'Puerto Rico'
      }
    },
    {
      "id": 3,
      "name": {'firstname':'Sandra','lastname':'Ward' },
      "phoneno": 8005122674,
      "address":{
        'street'  : '627 Minna Street',
        'state'   : 'Colorado',
        'city'    : 'Orin',
        'zipcode' : 644100,
        'country' : 'Germany'
      }
    },
    {
      "id": 4,
      "name": {'firstname':'Eve','lastname':'Hensley' },
      "phoneno": 8055352753,
      "address":{
        'street'  : '959 Greenwood Avenue',
        'state'   : 'Guam',
        'city'    : 'Wanship',
        'zipcode' : 645300,
        'country' : 'Argentina'
      }
    },
    {
      "id": 5,
      "name": {'firstname':'Sherry','lastname':'Rosa' },
      "phoneno": 8385152524,
      "address":{
        'street'  : '877 Bushwick Court',
        'state'   : 'Idaho',
        'city'    : 'Roberts',
        'zipcode' : 927500,
        'country' : 'Niger'
      }
    },
    {
      "id": 6,
      "name": {'firstname':'Rhodes','lastname':'Sharpe' },
      "phoneno": 8155453854,
      "address":{
        'street'  : '420 Hanover Place',
        'state'   : 'Massachusetts',
        'city'    : 'Shepardsville',
        'zipcode' : 978000,
        'country' : 'Chad'
      }
    },
    {
      "id": 7,
      "name": {'firstname':'Rosario','lastname':'Swanson' },
      "phoneno": 9985323875,
      "address":{
        'street'  : '530 Nevins Street',
        'state'   : 'Washington',
        'city'    : 'Hall',
        'zipcode' : 100400,
        'country' : 'Ireland'
      }
    },
    {
      "id": 8,
      "name": {'firstname':'Frazier','lastname':'Obrien' },
      "phoneno": 8254103897,
      "address":{
        'street'  : '570 Revere Place',
        'state'   : 'Connecticut',
        'city'    : 'Freeburn',
        'zipcode' : 628600,
        'country' : 'Tokelau'
      }
    },
    {
      "id": 9,
      "name": {'firstname':'Odom','lastname':'Blackwell' },
      "phoneno": 8494773756,
      "address":{
        'street'  : '565 Campus Place',
        'state'   : 'Kansas',
        'city'    : 'Grill',
        'zipcode' : 751200,
        'country' : 'Cyprus'
      }
    },
    {
      "id": 10,
      "name": {'firstname':'Jacquelyn','lastname':'Woods' },
      "phoneno": 8095313112,
      "address":{
        'street'  : '276 Harwood Place',
        'state'   : 'Indiana',
        'city'    : 'Cashtown',
        'zipcode' : 364500,
        'country' : 'China'
      }
    }
];
